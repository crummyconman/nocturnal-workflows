# Disclaimer

**Provided as is, with no warranty.** This script is free and comes with no warranty of any kind, express or implied, including that it will work, keep working, send every email, send at the right time, find every reply, or stay within Google's free limits. Google changes Apps Script, Gmail and Sheets, and their limits, and that can break the script. Check your `log` tab and your Sent folder regularly. Use it at your own risk.

**Not legal or tax advice.** Nothing in this download, including `COMPLIANCE_NOTES.md`, is legal, tax, accounting or debt-collection advice. Get advice from a qualified professional about your invoices, payment terms, late fees and how you contact customers.

**You are responsible for the emails and the law.** You, the person who installs and runs the script, are the sender of every email it sends, and you are responsible for:
- the wording of every message, including any changes you make to the templates (adding promotions or discounts makes them marketing email, with stricter rules),
- the accuracy of the amounts, dates, payment details and customer addresses in your sheet,
- following all laws and rules that apply to you, which may include CAN-SPAM and state email laws, debt-collection and consumer-protection laws, privacy and data-protection laws (such as GDPR or UK GDPR if you have customers there), and your industry's or licensing body's rules,
- honoring every request to stop, including requests that arrive in a new email or by phone, which the script can't see, and
- following Google's terms of service and Gmail's sending policies.

**Not for debt collection by third parties.** The templates are reminders from a business to its own customers. Don't use the script to collect debts for someone else. Only put late-fee terms in `late_fee_terms` that your customer already agreed to, and don't add threats or legal language.

**Your data.** Your customer data stays in your own Google account. The author of this script never receives it.

**No affiliation.** This project is not affiliated with, endorsed by or sponsored by Google, Intuit (QuickBooks), FreshBooks, Wave, Stripe or any other company. All trademarks belong to their owners.
