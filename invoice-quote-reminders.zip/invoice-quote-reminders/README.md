# Invoice Reminders + Quote Follow-Up (free Google Sheets script for freelancers and tradespeople)

**DRAFT. Not published.**

## What it does
You keep a list of invoices and quotes in a Google Sheet. Once a day, a small script in that sheet:
1. **Sends polite invoice reminders** 3, 7 and 14 days after the due date (you choose the days). The subject names the invoice and its due date ("Invoice INV-1001 from Example Plumbing Co, due November 10, 2026"). Each one gives the amount, the due date and how to pay, and says "If you've already paid, thank you. Please reply to let us know." If you fill in `late_fee_terms`, it adds that one line from your terms. It stops as soon as you set the row to **Paid** or **Stop**.
2. **Follows up on quotes** 2, 7 and 14 days after you sent them (you choose the days). It replies **inside the email thread of the quote you sent yourself**, so the customer sees it under your original quote. Each follow-up ends "Not interested? Just reply and I won't follow up again." and is signed with your business name and address. It stops when the customer replies, or when you set the row to **Won**, **Lost** or **Stop**.
3. **Notices replies.** On each daily run it checks the thread for a reply from the customer. Any reply stops the automatic emails for that invoice or quote and sets the row to **Replied**, so you can answer personally. Replies are picked up on the next daily run, not instantly.
4. **Honors STOP.** A reply with STOP, UNSUBSCRIBE (and similar words) adds the address to a `do_not_contact` tab. That address never gets another automatic email from this sheet.
5. **Emails you a short summary** whenever a run sent something or found a reply.

It's for people who bill from a spreadsheet, Word or Gmail. If you use QuickBooks, FreshBooks, Wave or Stripe invoicing, use their built-in reminders instead.

Built-in guardrails:
- **Test mode is on by default.** In test mode the script only emails your own address (`owner_email`) or a +alias of it, like `you+test1@gmail.com`. Every other address is skipped and logged. Nothing is redirected.
- Nothing is sent while a required setting is empty or any `{{placeholder}}` is left in a message.
- Addresses on `do_not_contact` are always skipped.
- Quote follow-ups are blocked until `business_address` is filled in (you get a note in the summary email). Invoice reminders can go without it.
- Every email goes to one person only, never with Cc or Bcc.
- Wording about collections, court, lawsuits, credit reports or ultimatum-style notices in the templates or `late_fee_terms` blocks the send.
- Never two emails to the same invoice or quote on the same day, even if you click "Run now" again. A lock stops two runs overlapping. `max_sends_per_run` (default 20) caps each run, and `max_sends_per_day` (default 50) caps each calendar day across all runs, including "Run now" clicks.
- No AI, no texting, no Make.com, no outside servers. The script only talks to your own Google Sheet and your own Gmail.

## What it costs
$0. It runs on Google Sheets, Gmail and Google Apps Script, all free with a Google account.

Limits:
- **Gmail sending limit:** a free (consumer) Gmail account can send to about **100 recipients a day** through Apps Script; Google Workspace accounts get about 1,500. The script stops at `max_sends_per_run` (default 20 per run) and at `max_sends_per_day` (default **50 per day**, counted across every run and "Run now" click; hard limit 90 for both). Whatever is left waits for the next run or the next day. "Send test to me" emails count toward the daily total too. The day is the sheet's calendar day; set the spreadsheet time zone (File > Settings) and the Apps Script project time zone (Project Settings) to the same zone.
- **Runs once a day**, around `send_hour` in the spreadsheet's time zone (File > Settings). Google picks the exact minute within that hour.
- **Replies are found in the email thread only.** If a customer writes back in a brand-new email, or from a different address than the one in the sheet, the script won't see it. Check your inbox and update the row.
- **Thread matching.** For a quote with no `thread_id`, the script uses your most recent sent email to that customer since the day before `sent_date` (one whose subject contains the `quote_id` first). If it finds none, it starts a new email with the subject "Following up on your quote". For invoices, it only replies in your sent email if the subject contains the `invoice_id`; otherwise it starts a new email. See "Tips" for making sure it picks the right thread.
- Apps Script itself has daily runtime limits; a sheet of a few hundred rows is well within them.

## What's in this folder
| File | What it is |
|---|---|
| `reminders.gs` | The Google Apps Script. The email wording is at the top. |
| `sheet-template-settings.csv` | The Settings tab, with every setting and a note on each |
| `sheet-template-invoices.csv`, `sheet-template-quotes.csv`, `sheet-template-do_not_contact.csv`, `sheet-template-log.csv` | Header rows for the other four tabs |
| `COMPLIANCE_NOTES.md` | The exact email templates and the rules they follow |
| `LICENSE.md`, `DISCLAIMER.md` | MIT license and no-warranty disclaimer |

## Setup (under 10 minutes)
**1. Make the sheet and paste the script (2 min).**
- Create a new Google Sheet, signed in as the Gmail account you send invoices and quotes from. Name it e.g. "Invoice and Quote Reminders".
- Go to **Extensions > Apps Script**. Delete the sample code, paste in all of `reminders.gs`, and click **Save**.

**2. Turn on the Gmail API advanced service (1 min). Required.**
- In the Apps Script editor, click **+** next to **Services** in the left sidebar, choose **Gmail API**, and click **Add** (leave the identifier as `Gmail`). It's free. The script uses it to reply inside the right email thread. Without it, every send fails with "Turn on the Gmail API advanced service".

**3. Create the tabs and authorize (2 min).**
- Go back to the sheet and reload the page. A **Nocturnal Workflows** menu appears (it can take a few seconds).
- Click **Nocturnal Workflows > Set up tabs**. Google asks you to authorize the script; see "How to authorize the script" below.
- This adds five tabs: `Settings`, `Invoices`, `Quotes`, `do_not_contact` and `log`. (Or create them yourself and paste in the CSV files. Tab names and column headers must match exactly.)

**4. Fill in Settings (2 min).** Replace every `{{...}}` value:
| Setting | What to put |
|---|---|
| `business_name` | Your business name. It's the From name and the sign-off. |
| `owner_email` | The Gmail address this script runs under. Test emails and summaries go here. |
| `reply_to` | Optional. Where replies should go, if not `owner_email`. Reply detection works best when replies come back to this same Gmail account. |
| `payment_instructions_or_link` | How to pay, e.g. a payment link or bank details. |
| `invoice_schedule_days` | Days after the due date for each reminder. Default `3,7,14`. |
| `quote_schedule_days` | Days after the quote was sent for each follow-up. Default `2,7,14`. |
| `max_sends_per_run` | Default `20`. Hard limit 90. |
| `max_sends_per_day` | Default `50`. Total per calendar day across all runs, including "Run now". Hard limit 90. The rest go out the next day. |
| `send_hour` | 0 to 23. Default `9` (around 9 a.m.). |
| `test_mode` | Leave `TRUE` until you've tested. |
| `business_address` | **Required for quote follow-ups.** A street address, PO box or registered private mailbox. Shown under your business name in every email. Until it's filled, quote follow-ups are paused; invoice reminders still go. |
| `late_fee_terms` | Optional, blank by default. One plain line copied from the terms your customer already agreed to, e.g. "Per our terms, a 1.5% late fee applies after 30 days." Leave blank and the line is left out. No collections, court, credit-report or ultimatum-style wording (the script blocks it). |
| `notify_owner` | `TRUE` emails you a summary after any run that did something. |
| `invoice_subject`, `invoice_body`, `quote_subject`, `quote_body` | Optional. Leave blank to use the wording in the script, or paste your own (keep it plain; see "Before you change the wording" below). |

**5. Send yourself a test (1 min).** Click **Nocturnal Workflows > Send test to me**. You get one sample invoice reminder and one sample quote follow-up, marked `[TEST]`, filled with made-up data. Read them.

**6. Test with your own +alias (2 min).** See the test plan below.

**7. Turn on the daily run.** Click **Nocturnal Workflows > Install daily trigger**. It creates one daily trigger (clicking again replaces it, never duplicates).

**8. Go live.** Set `test_mode` to `FALSE`. From the next run, real customers get emails.

### How to authorize the script
The first time you use the menu, Google shows a permissions screen:
1. Click **Continue** and pick your Google account.
2. You'll see **"Google hasn't verified this app."** That's normal for a script you pasted into your own sheet: you are the developer. Click **Advanced**, then **Go to (your project name) (unsafe)**.
3. Review the permissions and click **Allow**. The script asks to:
   - see and edit this spreadsheet (to read your rows and update status),
   - read, compose and send email in your Gmail (to find your sent quotes, check threads for replies, and send the reminders),
   - run when you're not there (the daily trigger).

The script never sends anything anywhere except emails from your own Gmail. You can read every line in `reminders.gs`, and you can remove access any time at myaccount.google.com > Security > Third-party connections.

### Filling the Invoices and Quotes tabs
- **Invoices:** `invoice_id`, `customer_name`, `customer_email`, `amount` (a number), `currency` (blank or `USD` shows `$`; anything else is shown after the amount), `due_date`, and `status` = `Open`. Leave `reminders_sent`, `last_reminder_at` and `thread_id` blank; the script fills them.
- **Quotes:** `quote_id` (put it in the subject of the quote email you send, e.g. "Quote Q-104 for deck repair", so the script finds the right thread), `customer_name`, `customer_email`, `description` (shown as "the quote you requested for **kitchen sink replacement**"), `amount`, `sent_date`, and `status` = `Open`.
- **Statuses:** Invoices: `Open`, `Paid`, `Stop`. Quotes: `Open`, `Won`, `Lost`, `Stop`. The script sets `Replied` or `Stop` itself. Only `Open` rows get emails. To restart after a reply, set the row back to `Open`.

## Test plan (made-up data, test_mode TRUE)
Use **+aliases of your own Gmail** as the customer address, e.g. `you+test1@gmail.com`. Mail to a +alias lands in your own inbox, and test mode only allows your own addresses, so no real person can get anything.

1. **Invoice reminder:** add an invoice row with `customer_email` = `you+inv1@gmail.com`, `due_date` = 3 days ago, `status` = `Open`. Click **Run now**. You get "Invoice ... due ..." and the row shows `reminders_sent` = 1 and a `thread_id`. Click **Run now** again: nothing more is sent today.
2. **Paid stops it:** set that row to `Paid`. Change `due_date` to 7 days ago and **Run now**: nothing is sent.
3. **Quote follow-up in your thread:** from Gmail, send yourself a fake quote to `you+quote1@gmail.com` with the subject "Quote Q-TEST for a sample job". Add a quote row with that address, `quote_id` = `Q-TEST`, `sent_date` = 2 days ago, `status` = `Open`. **Run now**. The follow-up appears as a reply under your fake quote, and the row gets its `thread_id`.
4. **Reply stops follow-ups:** open that thread and reply "Thanks, I'm still deciding." (Your reply comes from your own address; in test mode that counts as the customer.) **Run now**: the row changes to `Replied` and you get a summary email.
5. **STOP words:** repeat step 3 with `you+quote2@gmail.com`, then reply **STOP** (or "unsubscribe"). **Run now**: the alias is added to `do_not_contact`, the row changes to `Stop`, and nothing more is sent to that address from any row.
6. **Test mode blocks real people:** add a row with a made-up address like `someone@example.com` and **Run now**. The `log` tab shows it was skipped because of test mode.
7. **Clean up:** delete the test rows (keep real `do_not_contact` entries for good).

## 60-second demo script (faceless screen recording)
Use made-up names, +alias addresses and `test_mode` = `TRUE`. Before recording, pre-fill: one invoice for "Sample Client A" ($450, due 3 days ago, `you+demo1@gmail.com`), one quote for "Sample Client B" (kitchen sink replacement, sent 2 days ago, `you+demo2@gmail.com`) and a fake quote email you sent to that alias. Hide your real inbox and any real customer names.

| Time | On screen | Caption / voiceover |
|---|---|---|
| 0:00-0:05 | The sheet: Invoices tab, one Open row, due 3 days ago | "Chasing unpaid invoices is the worst part of the job. This sheet does it for you." |
| 0:05-0:12 | Settings tab: business name, payment link, `3,7,14`, test_mode TRUE | "Set your schedule once: 3, 7 and 14 days after the due date." |
| 0:12-0:20 | Click **Nocturnal Workflows > Run now**; the "Run finished: 2 sent" message | "It runs every morning on its own. Here I'm clicking Run now." |
| 0:20-0:30 | Gmail: the reminder email opened | "A polite reminder with the amount, the due date and how to pay. From your own Gmail." |
| 0:30-0:40 | Gmail: the quote follow-up, shown as a reply under the original quote | "Quotes get a friendly check-in, right in the same thread as your quote." |
| 0:40-0:50 | Reply "Thanks, still deciding", Run now, the row flips to **Replied** | "When they reply, it stops, so you can take it from there." |
| 0:50-0:55 | Invoices row set to **Paid** | "Mark it paid, and the reminders stop." |
| 0:55-1:00 | Title card | "Free download. No AI, no subscriptions, $0. Want it set up for you? Ask about an install." |

## Before you change the wording
- **You are the sender.** Every email goes out from your Gmail, in your business's name. You're responsible for what it says and for following the law where you and your customers are (see `DISCLAIMER.md`).
- **Don't add promotions or discounts.** Putting an offer, discount, sale, upsell or "book again and save" line into either template turns it into a **marketing (commercial) email**. Marketing email has stricter rules, such as an unsubscribe link in every message, and the reminders lose their "relationship email" footing. Keep both templates to the invoice or quote itself.
- **No pressure or threats.** Don't add collections, court, credit-report, ultimatum or countdown wording. The script blocks the most common phrases, but it can't catch everything.
- Keep the subject honest: it should say what the email is about.

## Tips
- **Help it find the right thread:** put the `quote_id` (or `invoice_id`) in the subject of the email you send, e.g. "Quote Q-104 for deck repair". The `log` tab shows which thread it linked ("Following up in your sent thread: ..."). If it ever links the wrong one, set the row to `Stop` and follow up by hand.
- You can also pass `thread_id` in yourself if you have an Apps Script thread id (e.g. from another script); otherwise leave it blank.
- **Change the wording** at the top of `reminders.gs` (`DEFAULT_TEMPLATES`) or in the Settings rows. Keep it plain and polite; see `COMPLIANCE_NOTES.md`.
- **Pause everything:** **Nocturnal Workflows > Remove daily trigger**.
- The `log` tab records every send, skip, block and reply.

## Want this set up for you?
Installs aren't available yet. On the download page, use the **"Ask about an install"** button (it opens an email to hello@nocturnalworkflows.com with the subject "Install request"), and we'll tell you when installs open.

## Compliance
See **`COMPLIANCE_NOTES.md`**. It's general information, not legal or tax advice; see `DISCLAIMER.md`.

## License
MIT. See `LICENSE.md`.
