# Compliance notes: Invoice Reminders + Quote Follow-Up

**For the Compliance agent's review. DRAFT, revision 2 (Compliance rules of Nov 15, 2026 applied).** General information, not legal or tax advice (see `DISCLAIMER.md`).

## What the script sends, and to whom
- **Invoice reminders:** to a customer who owes the sender for work already invoiced. Default: 3, 7 and 14 days after the due date (owner-editable). Stops when the row is Paid, Stop or Replied, or the address is on `do_not_contact`.
- **Quote follow-ups:** to a person who asked the sender for a quote, which the sender emailed them. Default: 2, 7 and 14 days after the quote was sent (owner-editable). Sent as a reply in the sender's own quote thread when one is found, otherwise as a new email. Stops on any reply, when the row is Won, Lost or Stop, or when the address is on `do_not_contact`.
- **Owner-only emails:** "Send test to me" samples (subject prefixed `[TEST] `) and an optional run summary. Only to `owner_email`.
- No texts, no AI-written text, no lists. Every recipient is a row the owner typed in. One recipient per email.

## Final templates (verbatim, as shipped in `reminders.gs` > `DEFAULT_TEMPLATES`)

### Invoice reminder
Subject (new thread):
```
Invoice {{invoice_id}} from {{business_name}}, due {{due_date}}
```
Body:
```
Hi {{customer_name}},

This is a reminder that invoice {{invoice_id}} for {{amount}} was due on {{due_date}}.

How to pay: {{payment_instructions}}

{{late_fee_terms}}

If you've already paid, thank you. Please reply to let us know so we can update our records. If you have a question about this invoice, just reply to this email.

Thanks,
{{footer}}
```

### Quote follow-up
Subject (new thread):
```
Following up on your quote
```
Body:
```
Hi {{customer_name}},

I'm checking in on the quote{{quote_ref}} you requested from {{business_name}} for {{description}}, sent on {{sent_date}}.

If you have any questions, or you'd like anything changed, just reply to this email.

Not interested? Just reply and I won't follow up again.

Thanks,
{{business_name}}
{{business_address}}
```

### Subject when replying in an existing thread
`Re: ` + the subject of the first email in that thread (e.g. "Re: Quote Q-100 for kitchen sink", or "Re: Invoice INV-1001 from Example Plumbing Co, due November 10, 2026"). If it already starts with "Re:", it's used as is.

### How the placeholders are filled
| Placeholder | Filled with |
|---|---|
| `{{customer_name}}` | Row customer_name, or "there" if blank |
| `{{business_name}}` | Settings: business_name (also the From name) |
| `{{business_address}}` | Settings: business_address (required for quotes) |
| `{{footer}}` | business_name, plus business_address on the next line if it's filled in (invoices) |
| `{{invoice_id}}` | Row invoice_id |
| `{{amount}}` | Row amount, e.g. `$450.00` (USD or blank currency) or `450.00 EUR` |
| `{{due_date}}`, `{{sent_date}}` | Row date, e.g. `November 10, 2026` |
| `{{payment_instructions}}` | Settings: payment_instructions_or_link |
| `{{late_fee_terms}}` | Settings: late_fee_terms, collapsed to one line. **If blank, the whole line and its blank line are removed.** |
| `{{quote_ref}}` | ` (Q-100)` if the row has a quote_id, otherwise empty |
| `{{description}}` | Row description |

### Rendered examples (made-up data)
Invoice, `late_fee_terms` filled:
```
Subject: Invoice INV-1001 from Example Plumbing Co, due November 10, 2026

Hi Alice,

This is a reminder that invoice INV-1001 for $450.00 was due on November 10, 2026.

How to pay: Pay online at https://pay.example.com

Per our terms, a 1.5% late fee applies after 30 days.

If you've already paid, thank you. Please reply to let us know so we can update our records. If you have a question about this invoice, just reply to this email.

Thanks,
Example Plumbing Co
123 Example St, Springfield, IL 62701
```
Invoice, `late_fee_terms` blank (the line is gone):
```
Subject: Invoice INV-1001 from Example Plumbing Co, due November 10, 2026

Hi Alice,

This is a reminder that invoice INV-1001 for $450.00 was due on November 10, 2026.

How to pay: Pay online at https://pay.example.com

If you've already paid, thank you. Please reply to let us know so we can update our records. If you have a question about this invoice, just reply to this email.

Thanks,
Example Plumbing Co
123 Example St, Springfield, IL 62701
```
Quote:
```
Subject: Following up on your quote

Hi Bob,

I'm checking in on the quote (Q-100) you requested from Example Plumbing Co for kitchen sink replacement, sent on November 10, 2026.

If you have any questions, or you'd like anything changed, just reply to this email.

Not interested? Just reply and I won't follow up again.

Thanks,
Example Plumbing Co
123 Example St, Springfield, IL 62701
```

## How each Compliance rule is met
| # | Rule | How it's met | Test(s) |
|---|---|---|---|
| 1 | Quote opt-out line is exactly "Not interested? Just reply and I won't follow up again."; STOP words still honored | Line is in `quote_body`; no "STOP" in the quote template. Any reply in the thread sets the row to Replied and stops follow-ups. Replies containing opt-out words (stop, unsubscribe, remove me, opt out, revoke, don't/do not email, don't/do not contact, no more emails; or a whole-reply cancel/end/quit/stopall) also add the address to `do_not_contact` and set Stop, blocking every row for that address. | "quote follow-ups at sent+2...", "a plain 'not interested' reply...", "a STOP-word reply still goes to do_not_contact...", "a STOP reply adds the address..." |
| 2 | business_address required for quotes; invoices may send without it; quote signature is name then address | `validateSettings_` adds a quote-only error when business_address is blank or contains `{{`. The run logs `BLOCKED_SETTINGS` ("business_address is empty or still a placeholder. It is required for quote follow-ups, so no quote follow-ups were sent.") and, if any quote is Open, the owner summary says "Quote follow-ups are paused: ...". Invoices sign off with the name only when the address is missing. Signature lines are `{{business_name}}` / `{{business_address}}`. | "business_address is required for quotes...", "invoice body includes business_address..." |
| 3 | Honest invoice subject with due date | `Invoice {{invoice_id}} from {{business_name}}, due {{due_date}}`; in-thread replies use "Re: original subject". | "invoice reminders go out at due+3...", "the shipped templates contain no banned wording..." |
| 4 | Optional late_fee_terms, blank by default, omitted when blank, one plain line when filled; no threat or ultimatum wording anywhere | Settings row ships blank. Newlines are collapsed to one line; an empty value removes the line. The script refuses to send if the templates (including owner edits) or late_fee_terms contain: "final notice", "last notice", collection(s), collection agency, court(s), small claims, legal action, lawsuit, sue, attorney, lawyer, credit bureau/report/score/rating/agency, debt collector. Row data (e.g. a "tennis court" job) isn't checked. None of this wording appears in the templates or README examples. | "late_fee_terms: blank leaves the line out...", "collections / court / credit / ... blocks the send", "the shipped templates contain no banned wording..." |
| 5 | Never Cc or Bcc | `sendMessage_` builds headers with To, From, optional Reply-To, Subject and In-Reply-To/References only; it refuses a To with more than one address. In-thread replies go only to the row's customer, even if the original email had a Cc. | "no send ever has Cc or Bcc headers, and only one recipient" |
| 6 | README warnings and setup step | README "Before you change the wording": promotions or discounts make it marketing email; you are the sender and responsible. Setup step 2 is the required Gmail API advanced-service step. | n/a (docs) |
| — | Plain, informational, no promotions/upsells/urgency | Same wording at every step, no offers, no deadlines. | shipped-template test |
| — | Sender identification | From name = business_name, sent from the owner's own Gmail; business name in the sign-off. | invoice step test |
| — | Volume limits | `max_sends_per_run` (default 20) and `max_sends_per_day` (default 50, tracked per calendar day across all runs); both capped at 90, under consumer Gmail's ~100/day. | daily-cap and per-run cap tests |
| — | Test mode | Only owner_email or its +alias can receive mail while test_mode is TRUE (default). | test_mode tests |

## Resolved questions (per Compliance, Nov 15, 2026)
1. **Opt-out from invoice reminders: resolved, behavior kept.** Invoice emails carry no opt-out line, but a STOP reply ends the reminders (row set to Stop) and adds the address to `do_not_contact`. The owner summary then says: "{customer_name} asked to stop automated emails. Invoice {invoice_id} is still unpaid, so you can follow up personally." (the email address is used if the name is blank). Test: "STOP reply to an invoice reminder: owner summary says ...".
2. **Owner-edited templates: resolved, README warning is sufficient.** The script blocks unfilled placeholders and threat wording; the README section "Before you change the wording" warns that promotions or discounts make either template marketing email and that the owner is the sender and responsible. No further control needed.

No open questions remain.
