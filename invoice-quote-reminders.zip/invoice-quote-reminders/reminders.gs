/**
 * Invoice Reminders + Quote Follow-Up (Nocturnal Workflows, free kit #2).
 * Google Apps Script, bound to one Google Sheet. No Make, no AI, no texting.
 *
 * Once a day (or when you click "Run now") it:
 *   1. Checks the Gmail thread of every Open invoice and quote for a reply from
 *      the customer. A reply containing STOP / UNSUBSCRIBE (etc.) adds the
 *      address to `do_not_contact` and sets the row to "Stop". Any other reply
 *      sets the row to "Replied" so you can answer it yourself.
 *   2. Sends the next quote follow-up (quote_schedule_days after sent_date) to
 *      Open quotes, replying in the thread of the quote you sent yourself.
 *   3. Sends the next invoice reminder (invoice_schedule_days after due_date)
 *      to Open invoices.
 *   4. Emails you a short summary if anything happened.
 *
 * Safety rules built in:
 *   - test_mode (TRUE by default) only sends to owner_email or a +alias of it
 *     (you+test1@gmail.com). Every other address is skipped and logged.
 *   - Nothing is sent while a required setting is empty or any {{placeholder}}
 *     is left in a message.
 *   - Addresses on `do_not_contact` are always skipped.
 *   - Quote follow-ups need business_address. Every email has one recipient
 *     (never Cc/Bcc). Collections, court, credit-report or "final notice"
 *     wording blocks the send.
 *   - A script lock stops two runs overlapping; a row never gets two messages
 *     on the same day; max_sends_per_run caps each run and max_sends_per_day
 *     caps each calendar day across all runs.
 *
 * One extra setup step: turn on the free "Gmail API" advanced service
 * (Extensions > Apps Script > Services > + > Gmail API > Add). It lets the
 * script reply inside the right email thread. See README.md.
 *
 * No passwords, keys or tokens live in this file.
 */

// ---------------------------------------------------------------------------
// EMAIL TEMPLATES. Edit the wording here, or paste your own version into the
// matching row of the Settings tab (a filled Settings row wins).
// Placeholders: {{customer_name}} {{business_name}} {{business_address}}
// {{invoice_id}} {{amount}} {{due_date}} {{payment_instructions}}
// {{late_fee_terms}} {{quote_ref}} {{description}} {{sent_date}} {{footer}}.
// {{late_fee_terms}} and {{footer}}'s address line disappear when blank.
// Keep the wording plain and informational. Adding promotions, discounts or
// offers turns these into marketing emails with stricter rules (README).
// ---------------------------------------------------------------------------
var DEFAULT_TEMPLATES = {
  invoice_subject: 'Invoice {{invoice_id}} from {{business_name}}, due {{due_date}}',
  invoice_body:
    'Hi {{customer_name}},\n\n' +
    'This is a reminder that invoice {{invoice_id}} for {{amount}} was due on {{due_date}}.\n\n' +
    'How to pay: {{payment_instructions}}\n\n' +
    '{{late_fee_terms}}\n\n' +
    "If you've already paid, thank you. Please reply to let us know so we can update our records. " +
    'If you have a question about this invoice, just reply to this email.\n\n' +
    'Thanks,\n' +
    '{{footer}}',
  quote_subject: 'Following up on your quote',
  quote_body:
    'Hi {{customer_name}},\n\n' +
    "I'm checking in on the quote{{quote_ref}} you requested from {{business_name}} for {{description}}, sent on {{sent_date}}.\n\n" +
    "If you have any questions, or you'd like anything changed, just reply to this email.\n\n" +
    "Not interested? Just reply and I won't follow up again.\n\n" +
    'Thanks,\n' +
    '{{business_name}}\n' +
    '{{business_address}}'
};

// ---------------------------------------------------------------------------
// Settings defaults (used when a Settings row is missing or blank).
// ---------------------------------------------------------------------------
var SETTING_DEFAULTS = {
  business_name: '',
  owner_email: '',
  reply_to: '',
  payment_instructions_or_link: '',
  invoice_schedule_days: '3,7,14',
  quote_schedule_days: '2,7,14',
  max_sends_per_run: '20',
  max_sends_per_day: '50',
  send_hour: '9',
  test_mode: 'TRUE',
  business_address: '',
  late_fee_terms: '',
  notify_owner: 'TRUE'
};
var MAX_SENDS_CEILING = 90;            // consumer Gmail allows ~100 recipients/day via Apps Script
var DAY_COUNT_PREFIX = 'daycount|';    // daycount|yyyy-MM-dd = emails sent that day (script time zone)
var SCRIPT_HEADER = 'X-Nocturnal-Workflows';
var SCRIPT_HEADER_VALUE = 'reminders-v1';
var HANDLER = 'dailyRun';
var MENU_NAME = 'Nocturnal Workflows';

var TABS = {
  settings: 'Settings',
  invoices: 'Invoices',
  quotes: 'Quotes',
  dnc: 'do_not_contact',
  log: 'log'
};
var HEADERS = {
  Invoices: ['invoice_id', 'customer_name', 'customer_email', 'amount', 'currency', 'due_date', 'status',
             'reminders_sent', 'last_reminder_at', 'thread_id', 'notes'],
  Quotes: ['quote_id', 'customer_name', 'customer_email', 'description', 'amount', 'sent_date', 'status',
           'followups_sent', 'last_followup_at', 'thread_id', 'notes'],
  do_not_contact: ['contact', 'opted_out_at', 'reply_text', 'source'],
  log: ['logged_at', 'type', 'id', 'email', 'action', 'detail'],
  Settings: ['key', 'value', 'notes']
};

// Opt-out words (same lists as the Instant Lead Response unsubscribe watcher).
// CONTAINS: matched anywhere in the subject or the new reply text.
var OPTOUT_KEYWORDS = ['stop', 'unsubscribe', 'remove me', 'opt out', 'optout', 'revoke',
                       "don't email", '\u2019t email', 'dont email', 'do not email',
                       "don't contact", 'do not contact', 'no more emails'];
// EXACT: short words that only count when they are the whole reply.
var OPTOUT_EXACT = ['cancel', 'end', 'quit', 'stopall', 'revoke', 'optout', 'unsubscribe', 'stop', 'opt out'];

// ---------------------------------------------------------------------------
// Menu and triggers
// ---------------------------------------------------------------------------
function onOpen() {
  SpreadsheetApp.getUi().createMenu(MENU_NAME)
    .addItem('Run now', 'menuRunNow')
    .addItem('Install daily trigger', 'installDailyTrigger')
    .addItem('Send test to me', 'sendTestToMe')
    .addSeparator()
    .addItem('Set up tabs', 'setupTabs')
    .addItem('Remove daily trigger', 'removeDailyTrigger')
    .addToUi();
}

function menuRunNow() {
  var r = dailyRun();
  alert_(r ? r.message : 'Another run is in progress. Try again in a minute.');
}

/** Creates any missing tab with its header row (and default Settings rows). Never overwrites. */
function setupTabs() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(HEADERS).forEach(function (name) {
    var sh = ss.getSheetByName(name);
    if (!sh) {
      sh = ss.insertSheet(name);
      sh.appendRow(HEADERS[name]);
      sh.setFrozenRows(1);
      if (name === TABS.settings) {
        settingsTemplateRows_().forEach(function (row) { sh.appendRow(row); });
      }
    }
  });
  alert_('Tabs are ready. Fill in the Settings tab next.');
}

function settingsTemplateRows_() {
  return [
    ['business_name', '{{BUSINESS_NAME}}', 'Shown in every email and as the From name'],
    ['owner_email', '{{OWNER_EMAIL}}', 'The Gmail address this script runs under. Gets test emails and summaries.'],
    ['reply_to', '', 'Optional. Where customer replies go. Leave blank to use owner_email.'],
    ['payment_instructions_or_link', '{{HOW_TO_PAY}}', 'e.g. a payment link, or bank transfer details'],
    ['invoice_schedule_days', '3,7,14', 'Days after the due date for reminder 1, 2, 3...'],
    ['quote_schedule_days', '2,7,14', 'Days after the quote was sent for follow-up 1, 2, 3...'],
    ['max_sends_per_run', '20', 'Cap per run (hard limit ' + MAX_SENDS_CEILING + ')'],
    ['max_sends_per_day', '50', 'Cap per calendar day, across all runs and Run now clicks (hard limit ' + MAX_SENDS_CEILING + '). The rest wait for the next day.'],
    ['send_hour', '9', '0-23, in the spreadsheet time zone. Used by the daily trigger.'],
    ['test_mode', 'TRUE', 'TRUE = only send to owner_email or a +alias of it. Set FALSE to go live.'],
    ['business_address', '{{BUSINESS_ADDRESS}}', 'Required for quote follow-ups (a street address, PO box or registered mailbox). Shown under your business name.'],
    ['late_fee_terms', '', 'Optional, blank by default. One plain line from your invoice terms, e.g. "Per our terms, a 1.5% late fee applies after 30 days." Leave blank to leave the line out.'],
    ['notify_owner', 'TRUE', 'TRUE = email you a short summary when a run did something'],
    ['invoice_subject', '', 'Optional. Leave blank to use the template in the script.'],
    ['invoice_body', '', 'Optional. Leave blank to use the template in the script.'],
    ['quote_subject', '', 'Optional. Leave blank to use the template in the script.'],
    ['quote_body', '', 'Optional. Leave blank to use the template in the script.']
  ];
}

/** Creates ONE daily trigger at send_hour. Removes an older one first, so never a duplicate. */
function installDailyTrigger() {
  var s = readSettings_();
  removeDailyTrigger_();
  ScriptApp.newTrigger(HANDLER).timeBased().everyDays(1).atHour(s.send_hour).create();
  var msg = 'Daily trigger installed: runs once a day around ' + s.send_hour + ':00 (spreadsheet time zone).';
  log_('system', '', '', 'TRIGGER_INSTALLED', msg);
  alert_(msg);
}

function removeDailyTrigger() {
  var n = removeDailyTrigger_();
  alert_(n ? 'Daily trigger removed.' : 'There was no daily trigger.');
}

function removeDailyTrigger_() {
  var n = 0;
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === HANDLER) { ScriptApp.deleteTrigger(t); n++; }
  });
  return n;
}

// ---------------------------------------------------------------------------
// Main run
// ---------------------------------------------------------------------------
/** Trigger handler (also used by "Run now"). Returns a summary object, or null if locked. */
function dailyRun() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) {
    Logger.log('Another run is still going; skipped.');
    return null;
  }
  try {
    return runLocked_();
  } finally {
    lock.releaseLock();
  }
}

function runLocked_() {
  var ctx = newContext_();
  var s = ctx.settings;
  if (ctx.errors.global.length) {
    var m = 'Nothing sent. Fix the Settings tab: ' + ctx.errors.global.join(' ');
    log_('system', '', '', 'BLOCKED_SETTINGS', m);
    return { message: m, sent: 0, events: ctx.events };
  }

  // 1. Replies and opt-outs on existing threads.
  checkReplies_(ctx, 'quote');
  checkReplies_(ctx, 'invoice');

  // 2. Quote follow-ups, then 3. invoice reminders.
  if (ctx.errors.quote.length) {
    ctx.counts.blocked++;
    log_('quote', '', '', 'BLOCKED_SETTINGS', ctx.errors.quote.join(' '));
    if (hasOpenRows_(TABS.quotes)) ctx.events.push('Quote follow-ups are paused: ' + ctx.errors.quote.join(' '));
  } else {
    sendDue_(ctx, 'quote');
  }
  if (ctx.errors.invoice.length) {
    ctx.counts.blocked++;
    log_('invoice', '', '', 'BLOCKED_SETTINGS', ctx.errors.invoice.join(' '));
    if (hasOpenRows_(TABS.invoices)) ctx.events.push('Invoice reminders are paused: ' + ctx.errors.invoice.join(' '));
  } else {
    sendDue_(ctx, 'invoice');
  }

  var summary = 'Run finished: ' + ctx.sent + ' sent' + (s.test_mode ? ' (test mode)' : '') + ', ' +
    ctx.counts.replied + ' replied, ' + ctx.counts.stopped + ' opted out, ' +
    ctx.counts.skipped + ' skipped, ' + ctx.counts.blocked + ' blocked.' +
    (ctx.capped ? ' Stopped at max_sends_per_run; the rest go next run.' : '') +
    (ctx.dayCapped ? ' Daily cap (max_sends_per_day) reached; the rest go tomorrow.' : '') +
    ' Sent today so far: ' + dayCount_(ctx) + ' of ' + s.max_sends_per_day + '.';
  log_('system', '', '', 'RUN_DONE', summary);
  notifyOwner_(ctx, summary);
  return { message: summary, sent: ctx.sent, events: ctx.events };
}

function newContext_() {
  var settings = readSettings_();
  var errors = validateSettings_(settings);
  // Calendar days (schedules and max_sends_per_day) use the spreadsheet's time zone,
  // falling back to the script's. Keep both the same (File > Settings, and
  // Apps Script > Project Settings) so "today" matches the daily trigger.
  var tz = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone() || Session.getScriptTimeZone();
  var now = new Date();
  return {
    settings: settings,
    errors: errors,
    tz: tz,
    now: now,
    today: dayStr_(now, tz),
    templates: readTemplates_(settings),
    dnc: readDnc_(),
    props: PropertiesService.getScriptProperties(),
    sent: 0,
    capped: false,
    dayCapped: false,
    counts: { replied: 0, stopped: 0, skipped: 0, blocked: 0 },
    events: []
  };
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
function readSettings_() {
  var raw = {};
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TABS.settings);
  if (sh) {
    sh.getDataRange().getValues().forEach(function (row, i) {
      if (i === 0 && String(row[0]).trim().toLowerCase() === 'key') return;
      var k = String(row[0] || '').trim().toLowerCase();
      if (k) raw[k] = row[1];
    });
  }
  var s = { raw: raw };
  Object.keys(SETTING_DEFAULTS).forEach(function (k) {
    var v = raw[k];
    s[k] = (v === undefined || v === null || String(v).trim() === '') ? SETTING_DEFAULTS[k] : v;
  });
  s.business_name = String(s.business_name).trim();
  s.owner_email = String(s.owner_email).trim().toLowerCase();
  s.reply_to = String(s.reply_to).trim();
  s.payment_instructions_or_link = String(s.payment_instructions_or_link).trim();
  if (String(s.business_address).trim() === '' && raw.postal_address) s.business_address = raw.postal_address;  // older sheets
  s.business_address = String(s.business_address).trim();
  s.business_address_ok = s.business_address !== '' && !hasPlaceholder_(s.business_address);
  s.late_fee_terms = String(s.late_fee_terms).replace(/\s+/g, ' ').trim();   // one line
  s.invoice_schedule = parseSchedule_(s.invoice_schedule_days);
  s.quote_schedule = parseSchedule_(s.quote_schedule_days);
  s.test_mode = parseBool_(s.test_mode);
  s.notify_owner = parseBool_(s.notify_owner);
  var cap = parseInt(s.max_sends_per_run, 10);
  s.max_sends_per_run = isNaN(cap) ? NaN : Math.min(cap, MAX_SENDS_CEILING);
  var dayCap = parseInt(s.max_sends_per_day, 10);
  s.max_sends_per_day = isNaN(dayCap) ? NaN : Math.min(dayCap, MAX_SENDS_CEILING);
  var hr = parseInt(s.send_hour, 10);
  s.send_hour = (isNaN(hr) || hr < 0 || hr > 23) ? 9 : hr;
  return s;
}

/** Returns {global:[], invoice:[], quote:[]} lists of problems. */
function validateSettings_(s) {
  var e = { global: [], invoice: [], quote: [] };
  if (!s.business_name || hasPlaceholder_(s.business_name)) e.global.push('business_name is empty or still a placeholder.');
  if (!isEmail_(s.owner_email)) e.global.push('owner_email must be a real email address.');
  if (s.reply_to && !isEmail_(s.reply_to)) e.global.push('reply_to must be an email address or blank.');
  if (s.test_mode === null) e.global.push('test_mode must be TRUE or FALSE.');
  if (isNaN(s.max_sends_per_run) || s.max_sends_per_run < 1) e.global.push('max_sends_per_run must be a number of 1 or more.');
  if (isNaN(s.max_sends_per_day) || s.max_sends_per_day < 1) e.global.push('max_sends_per_day must be a number of 1 or more.');
  if (!s.payment_instructions_or_link || hasPlaceholder_(s.payment_instructions_or_link)) {
    e.invoice.push('payment_instructions_or_link is empty or still a placeholder, so no invoice reminders were sent.');
  }
  if (hasPlaceholder_(s.late_fee_terms)) e.invoice.push('late_fee_terms still has a placeholder (leave it blank or fill it), so no invoice reminders were sent.');
  if (!s.business_address_ok) e.quote.push('business_address is empty or still a placeholder. It is required for quote follow-ups, so no quote follow-ups were sent.');
  if (!s.invoice_schedule) e.invoice.push('invoice_schedule_days must look like 3,7,14.');
  if (!s.quote_schedule) e.quote.push('quote_schedule_days must look like 2,7,14.');
  return e;
}

function readTemplates_(s) {
  var t = {};
  Object.keys(DEFAULT_TEMPLATES).forEach(function (k) {
    var v = s.raw[k];
    t[k] = (v === undefined || v === null || String(v).trim() === '') ? DEFAULT_TEMPLATES[k] : String(v);
  });
  return t;
}

function parseSchedule_(v) {
  var parts = String(v).split(/[,;\s]+/).filter(function (p) { return p !== ''; });
  if (!parts.length) return null;
  var out = [];
  for (var i = 0; i < parts.length; i++) {
    if (!/^\d+$/.test(parts[i])) return null;
    var n = parseInt(parts[i], 10);
    if (out.length && n <= out[out.length - 1]) return null;   // must increase
    out.push(n);
  }
  return out;
}

function parseBool_(v) {
  if (v === true || v === false) return v;
  var t = String(v).trim().toLowerCase();
  if (t === 'true' || t === 'yes' || t === '1') return true;
  if (t === 'false' || t === 'no' || t === '0') return false;
  return null;
}

// ---------------------------------------------------------------------------
// Rows
// ---------------------------------------------------------------------------
function typeConfig_(type) {
  return type === 'invoice'
    ? { tab: TABS.invoices, idCol: 'invoice_id', countCol: 'reminders_sent', lastCol: 'last_reminder_at',
        dateCol: 'due_date', schedule: 'invoice_schedule', label: 'invoice reminder' }
    : { tab: TABS.quotes, idCol: 'quote_id', countCol: 'followups_sent', lastCol: 'last_followup_at',
        dateCol: 'sent_date', schedule: 'quote_schedule', label: 'quote follow-up' };
}

/** Reads a tab into row objects: {_sheet, _row (1-based), _col{name:index}, values...}. */
function readRows_(tabName) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(tabName);
  if (!sh) throw new Error('Missing tab "' + tabName + '". Use ' + MENU_NAME + ' > Set up tabs.');
  var values = sh.getDataRange().getValues();
  if (!values.length) return [];
  var header = values[0].map(function (h) { return String(h).trim().toLowerCase(); });
  var col = {};
  header.forEach(function (h, i) { if (h) col[h] = i; });
  (HEADERS[tabName] || []).forEach(function (h) {
    if (col[h] === undefined) throw new Error('Tab "' + tabName + '" is missing the column "' + h + '".');
  });
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = { _sheet: sh, _row: r + 1, _col: col };
    header.forEach(function (h, i) { if (h) obj[h] = values[r][i]; });
    rows.push(obj);
  }
  return rows;
}

function setCell_(row, name, value) {
  row._sheet.getRange(row._row, row._col[name] + 1).setValue(value);
  row[name] = value;
}

function rowKey_(type, row) {
  var id = String(row[typeConfig_(type).idCol] || '').trim();
  return type + '|' + (id || ('row' + row._row + '|' + String(row.customer_email).trim().toLowerCase()));
}

function hasOpenRows_(tab) {
  return readRows_(tab).some(function (r) { return status_(r) === 'open'; });
}

function status_(row) {
  return String(row.status || '').trim().toLowerCase();
}

// ---------------------------------------------------------------------------
// Replies and opt-outs
// ---------------------------------------------------------------------------
function checkReplies_(ctx, type) {
  var cfg = typeConfig_(type);
  readRows_(cfg.tab).forEach(function (row) {
    if (status_(row) !== 'open') return;
    var threadId = String(row.thread_id || '').trim();
    var email = String(row.customer_email || '').trim().toLowerCase();
    if (!threadId || !isEmail_(email)) return;
    var thread;
    try { thread = GmailApp.getThreadById(threadId); } catch (err) { thread = null; }
    if (!thread) return;
    var reply = findCustomerReply_(ctx, row, type, thread);
    if (!reply) return;
    handleReply_(ctx, type, row, reply);
  });
}

/** Latest message in the thread that counts as a customer reply after our last send, or null. */
function findCustomerReply_(ctx, row, type, thread) {
  var cfg = typeConfig_(type);
  var email = String(row.customer_email).trim().toLowerCase();
  var anchor = anchorTime_(ctx, row, type, thread);
  var msgs = thread.getMessages();
  for (var i = msgs.length - 1; i >= 0; i--) {
    var m = msgs[i];
    if (m.getDate().getTime() <= anchor) break;
    if (isScriptMessage_(ctx, m)) continue;
    var from = bareAddress_(m.getFrom());
    if (from === email) return m;
    // Test mode: you reply to your own +alias test email from your own address.
    if (ctx.settings.test_mode && isOwnerAddress_(email, ctx.settings.owner_email) &&
        isOwnerAddress_(from, ctx.settings.owner_email)) {
      return m;
    }
  }
  return null;
}

/**
 * Replies only count if they arrived after this time:
 * the last automatic send; else, for quotes, your first message in the thread
 * on/after sent_date (the quote you sent yourself); for invoices, the due date.
 */
function anchorTime_(ctx, row, type, thread) {
  var cfg = typeConfig_(type);
  var stored = Number(ctx.props.getProperty('last|' + rowKey_(type, row)) || 0);
  if (stored) return stored;
  var last = row[cfg.lastCol];
  if (last instanceof Date && !isNaN(last.getTime())) return last.getTime();
  if (last && !isNaN(new Date(last).getTime())) return new Date(last).getTime();
  var rowDay = dayStr_(row[cfg.dateCol], ctx.tz);
  var email = String(row.customer_email).trim().toLowerCase();
  var msgs = thread.getMessages();
  if (type === 'invoice') {
    // Your invoice went out before it was due; only replies from the due date on count
    // (earlier ones are usually "got it, thanks").
    for (var j = 0; j < msgs.length; j++) {
      if (rowDay && dayStr_(msgs[j].getDate(), ctx.tz) >= rowDay) return msgs[j].getDate().getTime() - 1;
    }
    return msgs.length ? msgs[msgs.length - 1].getDate().getTime() : 0;
  }
  for (var i = 0; i < msgs.length; i++) {
    var from = bareAddress_(msgs[i].getFrom());
    var mine = from !== email || isScriptMessage_(ctx, msgs[i]);
    if (mine && (!rowDay || dayStr_(msgs[i].getDate(), ctx.tz) >= rowDay)) return msgs[i].getDate().getTime();
  }
  return msgs.length ? msgs[0].getDate().getTime() - 1 : 0;
}

function handleReply_(ctx, type, row, msg) {
  var cfg = typeConfig_(type);
  var id = String(row[cfg.idCol] || '');
  var email = String(row.customer_email).trim().toLowerCase();
  var text = stripQuoted_(msg.getPlainBody() || '');
  if (hasOptOutWord_(msg.getSubject()) || hasOptOutWord_(text)) {
    addToDnc_(ctx, email, text, type + ' ' + id);
    setCell_(row, 'status', 'Stop');
    ctx.counts.stopped++;
    log_(type, id, email, 'OPTED_OUT', 'Reply asked to stop. Added to do_not_contact; status set to Stop.');
    if (type === 'invoice') {
      var who = String(row.customer_name || '').trim() || email;
      ctx.events.push(who + ' asked to stop automated emails. Invoice ' + id +
        ' is still unpaid, so you can follow up personally.');
    } else {
      ctx.events.push('Opted out: ' + email + ' (' + type + ' ' + id + ')');
    }
  } else {
    setCell_(row, 'status', 'Replied');
    ctx.counts.replied++;
    log_(type, id, email, 'REPLIED', 'Customer replied, so automatic emails stopped. Reply: ' + text.substring(0, 200));
    ctx.events.push('Replied: ' + email + ' (' + type + ' ' + id + '). Please answer them.');
  }
}

function readDnc_() {
  var set = {};
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TABS.dnc);
  if (!sh) throw new Error('Missing tab "' + TABS.dnc + '". Use ' + MENU_NAME + ' > Set up tabs.');
  sh.getDataRange().getValues().forEach(function (r, i) {
    var c = String(r[0] || '').trim().toLowerCase();
    if (c && !(i === 0 && c === 'contact')) set[c] = true;
  });
  return set;
}

function addToDnc_(ctx, email, text, source) {
  if (ctx.dnc[email]) return;
  SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TABS.dnc)
    .appendRow([email, new Date(), String(text).substring(0, 500), source]);
  ctx.dnc[email] = true;
}

// ---------------------------------------------------------------------------
// Sending
// ---------------------------------------------------------------------------
function sendDue_(ctx, type) {
  var cfg = typeConfig_(type);
  var schedule = ctx.settings[cfg.schedule];
  var rows = readRows_(cfg.tab);
  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    if (status_(row) !== 'open') continue;          // Paid / Won / Lost / Stop / Replied / blank
    var id = String(row[cfg.idCol] || '').trim();
    var email = String(row.customer_email || '').trim().toLowerCase();
    var count = parseInt(row[cfg.countCol], 10) || 0;
    if (count >= schedule.length) continue;          // schedule finished
    var baseDay = dayStr_(row[cfg.dateCol], ctx.tz);
    if (!baseDay) { skip_(ctx, type, id, email, 'No valid ' + cfg.dateCol + '.'); continue; }
    if (daysBetween_(baseDay, ctx.today) < schedule[count]) continue;   // not due yet
    if (!isEmail_(email)) { skip_(ctx, type, id, email, 'customer_email is missing or not an email address.'); continue; }
    if (ctx.dnc[email]) { skip_(ctx, type, id, email, 'On do_not_contact.'); continue; }
    if (dayStr_(row[cfg.lastCol], ctx.tz) === ctx.today) continue;      // already sent today
    var key = rowKey_(type, row);
    if (ctx.props.getProperty('sent|' + key + '|' + (count + 1))) {
      // Sent before but the sheet wasn't updated (e.g. a crash). Repair, don't resend.
      setCell_(row, cfg.countCol, count + 1);
      log_(type, id, email, 'REPAIRED', cfg.label + ' ' + (count + 1) + ' was already sent; sheet updated, nothing resent.');
      continue;
    }
    if (ctx.settings.test_mode && !isOwnerAddress_(email, ctx.settings.owner_email)) {
      skip_(ctx, type, id, email, 'test_mode is TRUE, so only owner_email or a +alias of it gets emails.');
      continue;
    }
    if (ctx.sent >= ctx.settings.max_sends_per_run) { ctx.capped = true; return; }
    if (dayCount_(ctx) >= ctx.settings.max_sends_per_day) {
      if (!ctx.dayCapped) {
        ctx.dayCapped = true;
        log_('system', '', '', 'DAILY_CAP', 'max_sends_per_day (' + ctx.settings.max_sends_per_day +
          ') reached for ' + ctx.today + '. The rest go out tomorrow.');
      }
      return;
    }
    if (remainingQuota_() < 2) {
      ctx.capped = true;
      log_('system', '', '', 'QUOTA', 'Gmail daily sending quota reached; the rest go next run.');
      return;
    }

    // Find the thread to reply in (quote you sent, or our earlier reminder).
    var thread = resolveThread_(ctx, type, row);
    // Last check for a reply right before sending.
    if (thread) {
      var reply = findCustomerReply_(ctx, row, type, thread);
      if (reply) { handleReply_(ctx, type, row, reply); continue; }
    }

    var msg = render_(ctx, type, row, count + 1);
    if (msg.error) {
      ctx.counts.blocked++;
      log_(type, id, email, 'BLOCKED', msg.error);
      continue;
    }
    var res;
    try {
      res = sendMessage_(ctx, email, msg.subject, msg.body, thread);
    } catch (err) {
      log_(type, id, email, 'SEND_FAILED', String(err && err.message || err));
      continue;
    }
    var now = new Date();
    ctx.props.setProperty('sent|' + key + '|' + (count + 1), String(now.getTime()));
    ctx.props.setProperty('last|' + key, String(now.getTime()));
    ctx.props.setProperty('msg|' + res.id, '1');
    bumpDayCount_(ctx);
    setCell_(row, cfg.countCol, count + 1);
    setCell_(row, cfg.lastCol, now);
    if (res.threadId && String(row.thread_id || '') !== res.threadId) setCell_(row, 'thread_id', res.threadId);
    SpreadsheetApp.flush();
    ctx.sent++;
    log_(type, id, email, 'SENT', cfg.label + ' ' + (count + 1) + ' of ' + schedule.length +
      (thread ? ' (reply in existing thread)' : ' (new thread)') + (ctx.settings.test_mode ? ' [test mode]' : ''));
    ctx.events.push('Sent ' + cfg.label + ' ' + (count + 1) + ' to ' + email + (id ? ' (' + id + ')' : ''));
  }
}

/** Emails sent today (script time zone), across every run. */
function dayCount_(ctx) {
  return Number(ctx.props.getProperty(DAY_COUNT_PREFIX + ctx.today) || 0);
}

function bumpDayCount_(ctx) {
  ctx.props.setProperty(DAY_COUNT_PREFIX + ctx.today, String(dayCount_(ctx) + 1));
  // Forget counters from earlier days.
  var all = ctx.props.getProperties();
  Object.keys(all).forEach(function (k) {
    if (k.indexOf(DAY_COUNT_PREFIX) === 0 && k !== DAY_COUNT_PREFIX + ctx.today) ctx.props.deleteProperty(k);
  });
}

function skip_(ctx, type, id, email, why) {
  ctx.counts.skipped++;
  log_(type, id, email, 'SKIPPED', why);
}

/**
 * Thread to reply in, or null for a new thread.
 * 1. thread_id on the row.
 * 2. Quotes: your most recent Sent message to the customer since the day before
 *    sent_date (one whose subject has the quote_id first, if quote_id is set).
 *    Invoices: only a Sent message (last 120 days before due_date) whose subject
 *    has the invoice_id.
 * A found thread_id is saved to the row.
 */
function resolveThread_(ctx, type, row) {
  var cfg = typeConfig_(type);
  var saved = String(row.thread_id || '').trim();
  if (saved) {
    var t = null;
    try { t = GmailApp.getThreadById(saved); } catch (err) { t = null; }
    if (t) return t;
  }
  var email = String(row.customer_email).trim().toLowerCase();
  var id = String(row[cfg.idCol] || '').trim();
  // Quotes: sent on/after sent_date. Invoices go out before they're due, so look back 120 days from due_date.
  var after = afterDate_(row[cfg.dateCol], ctx.tz, type === 'invoice' ? 120 : 1);
  var base = 'in:sent to:' + email + (after ? ' after:' + after : '');
  var found = null;
  if (id) found = firstThread_(base + ' subject:"' + id.replace(/"/g, '') + '"');
  if (!found && type === 'quote') found = firstThread_(base);
  if (found) {
    setCell_(row, 'thread_id', found.getId());
    log_(type, id, email, 'THREAD_LINKED', 'Following up in your sent thread: "' + found.getFirstMessageSubject() + '"');
  }
  return found;
}

function firstThread_(query) {
  var threads = GmailApp.search(query, 0, 10);   // newest first
  return threads && threads.length ? threads[0] : null;
}

/** Fills a template. Returns {subject, body} or {error}. */
function render_(ctx, type, row, step) {
  var s = ctx.settings;
  var t = ctx.templates;
  var name = String(row.customer_name || '').trim();
  var address = s.business_address_ok ? s.business_address : '';
  var footer = s.business_name + (address ? '\n' + address : '');
  var vals = {
    customer_name: name || 'there',
    business_name: s.business_name,
    footer: footer,
    business_address: address,
    late_fee_terms: s.late_fee_terms,
    payment_instructions: s.payment_instructions_or_link,
    description: String(row.description || '').trim(),
    invoice_id: String(row.invoice_id || '').trim(),
    quote_ref: String(row.quote_id || '').trim() ? ' (' + String(row.quote_id).trim() + ')' : '',
    amount: formatAmount_(row.amount, row.currency),
    due_date: prettyDate_(row.due_date, ctx.tz),
    sent_date: prettyDate_(row.sent_date, ctx.tz),
    step: String(step)
  };
  if (type === 'invoice') {
    if (!vals.invoice_id) return { error: 'invoice_id is empty.' };
    if (!vals.amount) return { error: 'amount is empty or not a number.' };
  } else {
    if (!vals.description) return { error: 'description is empty.' };
  }
  var subject = fill_(t[type + '_subject'], vals).replace(/\s+/g, ' ').trim();
  var body = tidy_(fill_(t[type + '_body'], vals));
  if (hasPlaceholder_(subject) || hasPlaceholder_(body)) {
    return { error: 'Unfilled placeholder in the message: ' + (subject + ' ' + body).match(/\{\{[^}]*\}\}/)[0] + '. Nothing sent.' };
  }
  // Checked on the wording you control (templates, late_fee_terms), not on row
  // data, so a job description like "tennis court resurfacing" isn't blocked.
  var banned = bannedPhrase_(t[type + '_subject'] + '\n' + t[type + '_body'] +
    (type === 'invoice' ? '\n' + s.late_fee_terms : ''));
  if (banned) {
    return { error: 'The message contains "' + banned + '". Collections, court, credit-report and "final notice" wording is not allowed. Nothing sent.' };
  }
  return { subject: subject, body: body };
}

/** Removes the blank lines left by empty optional placeholders. */
function tidy_(body) {
  return String(body).replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

// Wording that turns a reminder into a threat. Checked in the templates
// (including your own edits) and late_fee_terms.
var BANNED_PATTERNS = [/final notice/i, /last notice/i, /\bcollections?\b/i, /collection agency/i, /\bcourts?\b/i,
  /small claims/i, /legal action/i, /\blawsuit/i, /\bsue\b/i, /\battorney/i, /\blawyer/i,
  /credit (bureau|report|score|rating|agenc)/i, /\bdebt collector/i];
function bannedPhrase_(text) {
  for (var i = 0; i < BANNED_PATTERNS.length; i++) {
    var m = String(text).match(BANNED_PATTERNS[i]);
    if (m) return m[0];
  }
  return '';
}

function fill_(tpl, vals) {
  return String(tpl).replace(/\{\{\s*([a-z_]+)\s*\}\}/g, function (m, k) {
    return Object.prototype.hasOwnProperty.call(vals, k) ? String(vals[k]) : m;
  });
}

/**
 * Sends through the Gmail API advanced service so we can reply inside an
 * existing thread to the customer (GmailApp's reply() would go to you, because
 * the last message in the thread is yours). Returns {id, threadId}.
 */
function sendMessage_(ctx, to, subject, body, thread) {
  var s = ctx.settings;
  var fromAddr = Session.getEffectiveUser().getEmail() || s.owner_email;
  // Only ever one recipient: no Cc or Bcc headers are ever added.
  var headers = [
    'MIME-Version: 1.0',
    'To: ' + to,
    'From: ' + encodeWord_(s.business_name) + ' <' + fromAddr + '>'
  ];
  if (s.reply_to) headers.push('Reply-To: ' + s.reply_to);
  if (/[,;]/.test(to)) throw new Error('One recipient per email only.');
  var resource = {};
  if (thread) {
    var msgs = thread.getMessages();
    var last = msgs[msgs.length - 1];
    var mid = last.getHeader('Message-ID') || last.getHeader('Message-Id');
    var orig = thread.getFirstMessageSubject() || subject;
    subject = /^re:/i.test(orig) ? orig : 'Re: ' + orig;
    if (mid) {
      headers.push('In-Reply-To: ' + mid);
      headers.push('References: ' + mid);
    }
    resource.threadId = thread.getId();
  }
  headers.push('Subject: ' + encodeWord_(subject));
  headers.push(SCRIPT_HEADER + ': ' + SCRIPT_HEADER_VALUE);
  headers.push('Content-Type: text/plain; charset=UTF-8');
  headers.push('Content-Transfer-Encoding: base64');
  var mime = headers.join('\r\n') + '\r\n\r\n' + Utilities.base64Encode(body, Utilities.Charset.UTF_8);
  resource.raw = Utilities.base64EncodeWebSafe(mime, Utilities.Charset.UTF_8);
  if (typeof Gmail === 'undefined') {
    throw new Error('Turn on the Gmail API advanced service (Services > + > Gmail API). See README step 4.');
  }
  var sent = Gmail.Users.Messages.send(resource, 'me');
  return { id: sent.id, threadId: sent.threadId };
}

function encodeWord_(s) {
  return /^[\x20-\x7e]*$/.test(s) ? s.replace(/[\r\n]/g, ' ')
    : '=?UTF-8?B?' + Utilities.base64Encode(s, Utilities.Charset.UTF_8) + '?=';
}

function isScriptMessage_(ctx, m) {
  if (ctx.props.getProperty('msg|' + m.getId())) return true;
  try { return String(m.getHeader(SCRIPT_HEADER) || '') !== ''; } catch (err) { return false; }
}

function remainingQuota_() {
  try { return MailApp.getRemainingDailyQuota(); } catch (err) { return 100; }
}

// ---------------------------------------------------------------------------
// "Send test to me": one sample invoice reminder and one sample quote
// follow-up, filled with made-up data, sent only to owner_email.
// ---------------------------------------------------------------------------
function sendTestToMe() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) { alert_('A run is in progress. Try again in a minute.'); return null; }
  try {
    var ctx = newContext_();
    if (ctx.errors.global.length) {
      var m = 'Test not sent. Fix the Settings tab: ' + ctx.errors.global.join(' ');
      log_('test', '', '', 'BLOCKED_SETTINGS', m);
      alert_(m);
      return { sent: 0, message: m };
    }
    var sample = {
      invoice: { invoice_id: 'INV-TEST-001', customer_name: 'Sample Customer', amount: 450, currency: 'USD',
                 due_date: addDays_(ctx.today, -3) },
      quote: { quote_id: 'Q-TEST-001', customer_name: 'Sample Customer', description: 'a sample job',
               amount: 1200, currency: 'USD', sent_date: addDays_(ctx.today, -2) }
    };
    var sent = 0, notes = [];
    ['invoice', 'quote'].forEach(function (type) {
      if (ctx.errors[type].length) { notes.push(ctx.errors[type].join(' ')); log_('test', '', ctx.settings.owner_email, 'BLOCKED_SETTINGS', ctx.errors[type].join(' ')); return; }
      var msg = render_(ctx, type, sample[type], 1);
      if (msg.error) { notes.push(type + ': ' + msg.error); log_('test', '', ctx.settings.owner_email, 'BLOCKED', msg.error); return; }
      sendMessage_(ctx, ctx.settings.owner_email, '[TEST] ' + msg.subject, msg.body, null);
      bumpDayCount_(ctx);   // counts toward max_sends_per_day (not blocked by it: it only emails you)
      sent++;
      log_('test', sample[type][typeConfig_(type).idCol], ctx.settings.owner_email, 'SENT', 'Sample ' + typeConfig_(type).label + ' sent to you.');
    });
    var out = sent + ' test email(s) sent to ' + ctx.settings.owner_email + '.' + (notes.length ? ' ' + notes.join(' ') : '');
    alert_(out);
    return { sent: sent, message: out };
  } finally {
    lock.releaseLock();
  }
}

function notifyOwner_(ctx, summary) {
  if (!ctx.settings.notify_owner || !ctx.events.length) return;
  var body = summary + '\n\n' + ctx.events.map(function (e) { return '- ' + e; }).join('\n') +
    '\n\nDetails are in the log tab of your sheet.';
  try {
    GmailApp.sendEmail(ctx.settings.owner_email, MENU_NAME + ': reminders run summary', body, { name: MENU_NAME });
  } catch (err) {
    Logger.log('Summary email failed: ' + err);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function log_(type, id, email, action, detail) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(TABS.log);
  if (sh) sh.appendRow([new Date(), type, id, email, action, String(detail).substring(0, 1000)]);
  Logger.log([type, id, email, action, detail].join(' | '));
}

function alert_(msg) {
  try { SpreadsheetApp.getUi().alert(msg); } catch (err) { Logger.log(msg); }   // no UI when run by trigger
}

function hasPlaceholder_(s) {
  return /\{\{[^}]*\}\}/.test(String(s || ''));
}

function isEmail_(s) {
  return /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']+$/.test(String(s || '').trim());
}

/** True if addr is owner itself or owner's +alias (you+anything@same-domain). */
function isOwnerAddress_(addr, owner) {
  var a = String(addr || '').trim().toLowerCase().split('@');
  var o = String(owner || '').trim().toLowerCase().split('@');
  if (a.length !== 2 || o.length !== 2 || a[1] !== o[1]) return false;
  return a[0].split('+')[0] === o[0].split('+')[0];
}

/** "Name <a@b.com>" -> "a@b.com" (lower case). */
function bareAddress_(from) {
  var s = String(from || '');
  var m = s.match(/<([^>]+)>/);
  var addr = m ? m[1] : s;
  var m2 = addr.match(/[^\s<>"']+@[^\s<>"']+/);
  return (m2 ? m2[0] : addr).trim().toLowerCase();
}

/** Keep only the new text: cut at "wrote:" (and its "On ..." line) or "-----Original". */
function stripQuoted_(body) {
  var text = String(body).replace(/\r\n/g, '\n');
  var cut = text.length;
  var w = text.indexOf('wrote:');
  if (w !== -1) {
    var onLine = text.lastIndexOf('\nOn ', w);
    if (onLine === -1 && text.indexOf('On ') === 0) onLine = 0;
    cut = Math.min(cut, onLine !== -1 && w - onLine < 300 ? onLine : w);
  }
  var o = text.indexOf('-----Original');
  if (o !== -1) cut = Math.min(cut, o);
  text = text.substring(0, cut);
  text = text.split('\n').filter(function (l) { return !/^\s*>/.test(l); }).join('\n');
  return text.trim();
}

function hasOptOutWord_(s) {
  var t = String(s || '').toLowerCase();
  if (OPTOUT_KEYWORDS.some(function (k) { return t.indexOf(k) !== -1; })) return true;
  var whole = t.replace(/^re:\s*/, '').replace(/[.!,?"']/g, '').replace(/\s+/g, ' ').trim();
  return OPTOUT_EXACT.indexOf(whole) !== -1;
}

/** Any date cell -> "yyyy-MM-dd" in the sheet's time zone, or "" if not a date. */
function dayStr_(v, tz) {
  if (v === null || v === undefined || v === '') return '';
  if (v instanceof Date) return isNaN(v.getTime()) ? '' : Utilities.formatDate(v, tz, 'yyyy-MM-dd');
  var s = String(v).trim();
  var m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return m[1] + '-' + pad2_(m[2]) + '-' + pad2_(m[3]);
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);          // US style m/d/yyyy
  if (m) return m[3] + '-' + pad2_(m[1]) + '-' + pad2_(m[2]);
  return '';
}

function pad2_(n) { n = String(n); return n.length < 2 ? '0' + n : n; }

function dayToUtc_(day) {
  var p = day.split('-');
  return Date.UTC(+p[0], +p[1] - 1, +p[2]);
}

function daysBetween_(fromDay, toDay) {
  return Math.round((dayToUtc_(toDay) - dayToUtc_(fromDay)) / 86400000);
}

function addDays_(day, n) {
  var d = new Date(dayToUtc_(day) + n * 86400000);
  return d.getUTCFullYear() + '-' + pad2_(d.getUTCMonth() + 1) + '-' + pad2_(d.getUTCDate());
}

/** Gmail "after:" value: `back` days before the row's date, as yyyy/MM/dd. */
function afterDate_(v, tz, back) {
  var d = dayStr_(v, tz);
  return d ? addDays_(d, -back).replace(/-/g, '/') : '';
}

var MONTHS_ = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
               'September', 'October', 'November', 'December'];
function prettyDate_(v, tz) {
  var d = dayStr_(v, tz);
  if (!d) return '';
  var p = d.split('-');
  return MONTHS_[+p[1] - 1] + ' ' + (+p[2]) + ', ' + p[0];
}

function formatAmount_(amount, currency) {
  var n = typeof amount === 'number' ? amount : parseFloat(String(amount || '').replace(/[^0-9.\-]/g, ''));
  if (isNaN(n)) return '';
  var fixed = n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  var c = String(currency || '').trim().toUpperCase();
  if (!c || c === 'USD') return '$' + fixed;
  return fixed + ' ' + c;
}
