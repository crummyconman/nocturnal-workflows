# Instant Lead Response (free Make.com workflow for real estate agents)

**DRAFT. Not published.**

## What it does
1. A lead fills in your web form (Tally) and ticks the consent box.
2. Within about a minute they get a short, personal email reply. It's written by Google Gemini, identifies itself as your automated assistant, repeats only what the lead asked about, asks one timeline question, and ends with "Reply STOP to opt out."
3. You get a Telegram alert on your phone with the lead's details and the exact message that went out, so you can call them right away.
4. Every lead is logged in a Google Sheet (your consent record).
5. Replies like STOP or UNSUBSCRIBE add the lead to a `do_not_contact` tab and alert you, and that lead never gets another automatic message.

Built-in guardrails:
- The workflow checks consent and the do-not-contact list before anything goes out.
- Quiet hours: it only sends from 8 a.m. to 8 p.m. local time. Leads that arrive outside those hours are held, and you get an alert.
- The AI prompt includes Fair Housing rules.
- A pre-send check swaps in a safe fallback message whenever the AI text is too long, is missing the opt-out line, contains a link, or uses a flagged word.

The consent wording, send rules, opt-out words, message lines, footer and Fair Housing rules all come from **`compliance_building_blocks.md`**. Read **`COMPLIANCE_NOTICE.md`** before you switch anything on.

## What it costs
Can run on free tiers, with limits: Make Free, the Google Gemini API free tier, Gmail, Google Sheets, Google Apps Script, Telegram and Tally Free.

Free-tier limits:
- **Make Free:** 2 active scenarios (this workflow uses exactly 2: A and U) and about 1,000 credits a month. Each emailed lead uses about **9 credits**, so you get roughly 100 emailed leads a month. Each opt-out uses about 3 credits, and a blocked or no-consent lead uses 4 to 5. Make Free also allows only 1 data store, which `queued_leads` uses.
- **Gemini free tier:** Google may use what you send it to improve its products, and rate limits apply. **Use made-up test leads only.** Move to a paid Gemini tier, or a provider whose terms exclude training, before any real lead data passes through.
- **After-hours leads are stored, not sent.** Leads that arrive outside 8 a.m. to 8 p.m. are saved in the `queued_leads` data store and you get an alert, but the free version **does not send them automatically** in the morning. That would need a third scenario, and Make Free allows only 2. Follow up on them yourself, or upgrade Make and add a morning sender that re-checks consent, the do-not-contact list and quiet hours at send time (send rule 3 in `compliance_building_blocks.md`).
- **SMS is off.** The Twilio text-message route is in the blueprint but can never fire (see step 12).

## What's in this folder
| File | What it is |
|---|---|
| `ilr-scenario-a-new-lead.blueprint.json` | Make scenario A: form webhook, do-not-contact check, consent and quiet-hours router, Gemini, pre-send check, email, Telegram alert, Sheets log |
| `ilr-scenario-u-unsubscribe.blueprint.json` | Make scenario U: opt-out webhook, opt-out word filter, `do_not_contact` row, Telegram alert |
| `unsubscribe-watcher.gs` | Google Apps Script that checks Gmail every 5 minutes for opt-out replies and posts them to scenario U |
| `sheet-template-leads.csv`, `sheet-template-do_not_contact.csv`, `sheet-template-blocked_messages.csv` | Header rows for the three Google Sheet tabs |
| `compliance_building_blocks.md` | Consent wording, send rules, opt-out words, message and footer lines, and Fair Housing prompt rules |
| `COMPLIANCE_NOTICE.md` | Compliance notice. Read it first. |
| `LICENSE.md`, `DISCLAIMER.md` | MIT license and no-warranty disclaimer |

## Placeholders
Two placeholder styles, because Make treats `{{ }}` as its own formula syntax:
- In the **Make blueprints**, placeholders look like `[[AGENT_NAME]]`.
- In **`unsubscribe-watcher.gs` and the docs**, they look like `{{SCENARIO_U_WEBHOOK_URL}}`.

| Placeholder | Where | Fill with |
|---|---|---|
| `[[AGENT_NAME]]` | Scenario A, module "Lead + agent variables" (`agent_name`, `fallback_text`) | The agent's name as it should appear in messages |
| `[[AGENT_BUSINESS_NAME]]`, `[[AGENT_CITY]]` | Same module (`agent_business`, `fallback_text`) | The brokerage or team name and city, e.g. "Example Realty, Austin" |
| `[[POSTAL_ADDRESS]]` | Same module (`postal_address`), shown in the email footer | A real postal address: street address, PO box or registered private mailbox. **CAN-SPAM requires one before real use.** |
| `[[UNSUBSCRIBE_EMAIL]]` | Same module (`unsubscribe_email`), used for the footer's unsubscribe mailto link | The Gmail address Scenario A sends from, so the watcher sees the unsubscribe emails |
| `[[MARKET_TIMEZONE]]` | Scenario A `local_hour`; Scenario U, module "Add to do_not_contact" | An IANA time zone such as `America/Chicago` or `America/New_York` |
| `[[TALLY_CONSENT_OPTION_KEY]]` | Scenario A `consent` | The key of the ticked consent option from your Tally payload (step 9) |
| `[[SPREADSHEET_ID]]` | Every Google Sheets module (A: 3 modules, plus 1 more if you keep the blocked-message log; U: 1) | Re-select your sheet in each module |
| `[[TELEGRAM_CHAT_ID]]` | Every Telegram module (A: 3, U: 1) | Your chat id (step 3) |
| `[[TWILIO_SENDER_NUMBER]]` | SMS module (disabled) | Leave it unless you later register an SMS sender |
| `{{SCENARIO_U_WEBHOOK_URL}}`, `{{SENDER_EMAIL}}` | `unsubscribe-watcher.gs` | Scenario U's webhook address, and the sending Gmail address |

Safety net: the email route only runs once `agent_name`, `agent_business`, `postal_address` and `unsubscribe_email` no longer contain `[[`. Until you fill them, nothing emails a lead.

## Setup, step by step (about 1 to 2 hours)

**1. Google Sheet.**
- Create a Google Sheet (e.g. "Lead Response") with three tabs named exactly `leads`, `do_not_contact` and `blocked_messages`.
- Paste the matching CSV header row into row 1 of each tab.
- Column order matters: Scenario A writes `leads` by column position (A to L), and the do-not-contact check reads column A of `do_not_contact`.
- (Phone numbers are written with a leading apostrophe so Sheets keeps the `+`.)

**2. Gmail.**
- Use the Gmail account that will send the lead emails. The **From name** must be the agent or brokerage named in the message (`compliance_building_blocks.md` section 4).
- Set the account's display name under Gmail Settings > Accounts > "Send mail as" > edit info.

**3. Telegram bot and chat id.**
- In Telegram, message **@BotFather**, send `/newbot`, and follow the prompts. Copy the bot token it gives you and keep it private; it only goes into Make's Telegram connection (step 6).
- Open your new bot and send it any message.
- In a browser, open `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates` and copy `message.chat.id`. That's your `[[TELEGRAM_CHAT_ID]]`.
- Don't paste the token into chats, docs or screenshots.

**4. Gemini API key.**
- Go to **Google AI Studio** (aistudio.google.com) > Get API key > Create API key.
- Keep it private; it goes only into Make's Gemini connection.
- Remember the free-tier data note above.

**5. Import both blueprints into Make.**
- In Make, go to Scenarios > Create a new scenario > the "..." menu > **Import Blueprint**, and choose `ilr-scenario-a-new-lead.blueprint.json`. Save it.
- Repeat with `ilr-scenario-u-unsubscribe.blueprint.json`.
- Connections, webhooks, the data store and the sheet are deliberately blank in the files. **You re-select all of them after import** (steps 6 to 8).
- Leave both scenarios **off** for now.

**6. Create the connections.** Open each module with a red warning and pick or create a connection:
- **Google Sheets:** your Google account (do-not-contact check, `leads`, `blocked_messages`, `do_not_contact` in U).
- **Gmail:** the sending account ("Email the lead").
- **Google Gemini AI:** the API key from step 4. Check that the model in "Gemini: first message" is still offered. The blueprint uses `gemini-3.5-flash-lite`; pick the closest current Flash-Lite model if it isn't listed.
- **Telegram Bot:** the token from step 3 (3 modules in A, 1 in U). Set **Chat ID** to `[[TELEGRAM_CHAT_ID]]`'s value in each.
- **Twilio:** leave it unconnected.

Then, in every Google Sheets module, re-select your spreadsheet and the right tab: `do_not_contact` for "Check do_not_contact" and U's "Add to do_not_contact", `leads` for both log modules, and `blocked_messages` for the blocked log.

**7. Webhooks.**
- In Scenario A, open "ILR new lead" > Add > name it, and copy its address. You'll need it in step 9.
- In Scenario U, open "ILR unsubscribe webhook" > Add, and copy its address. That's `{{SCENARIO_U_WEBHOOK_URL}}`, used in step 10.
- Treat both URLs as private.

**8. Data store `queued_leads`.**
- In Make, go to Data stores > Add, name it `queued_leads`, and create a data structure with these fields:
  - `name`, `first_name`, `email`, `phone`, `source`, `interest`, `area_or_property`, `lead_message`, `consent`, `consent_version`, `received_at` and `page_url` (all **Text**)
  - `sent` (**Boolean**)
- Select it in Scenario A's "Queue lead (queued_leads)" module.

**9. Tally form.** Create a free Tally form with these fields. Labels must match exactly, because the scenario looks them up by label:
- **First name** (short text), **Last name** (short text), **Email** (email), **Mobile phone** (phone).
- **What are you looking for?** (multiple choice: Buying, Selling, Both, Just browsing).
- **Area or property of interest** (short text).
- **Anything else we should know?** (long text).
- **Consent checkbox:** a Checkboxes question with one option. Use the exact wording from **`compliance_building_blocks.md` section 1** (version `consent-1.0`), with your legal name and your privacy policy and terms links filled in. Make it **optional** and **unchecked by default**, and put it right above the submit button. The form must submit without it.
  > {{CONSENT_CHECKBOX_WORDING}}: copy it from `compliance_building_blocks.md` section 1. Compliance owns this text; don't edit it here.
- **Hidden fields:** `consent_version` and `page_url`. Pass them in the form link or embed, e.g. `?consent_version=consent-1.0&page_url=<your page>`. If `consent_version` is empty, the scenario stores `consent-1.0`.
- Under Integrations > **Webhooks**, paste Scenario A's webhook address.
- In Make, click "Run once" on Scenario A, submit one test entry with consent ticked, and let the webhook learn the data structure.
- Open the run's webhook output, find the field whose `value` is `true` with a key like `question_XXXX_<long id>` (the ticked consent option), and paste that key in place of `[[TALLY_CONSENT_OPTION_KEY]]` in the `consent` variable.
- If that key is still a placeholder, every lead counts as **no consent** and gets no auto-reply. That's the safe default.

**10. Apps Script unsubscribe watcher.**
- Signed in as the sending Gmail account, go to script.google.com > New project and paste in `unsubscribe-watcher.gs`.
- Fill `{{SCENARIO_U_WEBHOOK_URL}}` and `{{SENDER_EMAIL}}`. If you change the email subject in Scenario A, update `SUBJECT` too.
- Select `setup` and click Run, then approve the Gmail and external-request permissions. It creates **one** time-driven trigger that runs `checkOptOuts` every 5 minutes. Check it under Triggers.
- The script finds replies to "Your real estate inquiry" (including the footer's unsubscribe mailto, whose subject starts "Unsubscribe - "), ignores quoted text, and posts opt-outs to Scenario U.
- The opt-out words are in `compliance_building_blocks.md` section 3:
  - Phrases like stop, unsubscribe, remove me, opt out, revoke, "don't text", "do not contact" and "wrong number" count anywhere in the reply or subject.
  - Short words (cancel, end, quit) count only when they're the whole reply.
- Apps Script is free and uses no Make credits until it finds an opt-out.

**11. Fill every placeholder** in the table above.
- In Make, search each scenario for `[[` and make sure nothing is left.
- In the Apps Script, search for `{{`.

**12. SMS stays off.**
- The "SMS to lead" route has a filter condition that is never true (`sms_disabled = sms_enabled`), and `channel` is set to `email`.
- Only turn SMS on after you have:
  - your **own** registered sender (A2P 10DLC or toll-free verification approved for your business),
  - TCPA-grade written consent from section 1, a published privacy policy and terms, and
  - a review by a lawyer or your broker.
- To turn it on: connect Twilio, set `[[TWILIO_SENDER_NUMBER]]`, delete the never-true condition, and set `channel` to `sms`.

**13. Turn on Scenario A, then Scenario U** (scheduling: immediately). Then run the test plan.

## Test plan (made-up leads only)
Use invented names, and send to **+aliases of your own Gmail** (e.g. `you+test1@gmail.com`) so no real person gets anything. Never use a real person's details while Gemini is on the free tier.

1. **Happy path**, between 8 a.m. and 8 p.m., with consent ticked:
   - An email arrives in about a minute. It starts "Hi <name>, this is <agent>'s automated assistant at <business>.", ends "Reply STOP to opt out.", and the footer shows your business, your address and an unsubscribe link.
   - You get a Telegram alert, and a `leads` row appears with `seconds_to_send`.
2. **No consent:** untick the box. You get a "WITHOUT consent" Telegram alert only. No email, no Gemini call.
3. **Quiet hours:** temporarily set `[[MARKET_TIMEZONE]]` to a zone where it's after 8 p.m.
   - The lead is saved in `queued_leads` with a "queued" alert, and no email is sent.
   - Set the zone back afterwards and delete the test record.
4. **Fair Housing:** in "Anything else we should know?", ask "Is it a good area for kids?"
   - The reply should hand off ("That's a great question for <agent> - I'll have them reach out to you directly.") with no comment on the area.
   - If the AI text ever trips the keyword filter, the fallback text is sent and a `blocked_messages` row is logged.
5. **Fallback:** temporarily break the Gemini connection (or the model name). The fallback text still sends.
6. **Opt-out:** reply "STOP" to a test email.
   - Within about 5 minutes the address is on `do_not_contact` and you get an "unsubscribed" alert.
   - Then submit the form again with that address. You should get a "BLOCKED" `leads` row and no email.
   - Repeat with the footer's unsubscribe link.
7. **Credits:** after 5 test leads, check the Make credit counter. It should be about 9 per emailed lead.
8. **Clean up:** delete the test rows (but never real `do_not_contact` entries; keep those at least 5 years) and the test records in the data store.

## Known differences from `compliance_building_blocks.md`
The blueprints follow the building blocks where they can. These items are **not** automated in the free version:
- **Send rule 4, the 24-hour duplicate guard:** not built in. If the same person submits twice, they get two replies.
- **Send rule 3, the recheck at send time for held leads:** queued leads aren't auto-sent at all in the free version, so there's nothing to recheck. If you send them by hand, check the do-not-contact list and quiet hours first.
- **Order of checks:** all of rules 1 to 3 are checked together in one router filter, after a single do-not-contact lookup. A lead on the list is always blocked, whatever their consent.
- **AI opt-out detection** (section 3, plain-language requests): replies are matched against the word and phrase list, not read by the AI. Unusual wording may be missed, so read replies yourself.
- **Opt-out confirmation and HELP replies:** not sent. Both are optional for email; for SMS, add them before you turn SMS on.
- **Quiet hours** use one market time zone, not each lead's own.
- **Questions:** the prompt allows at most **one** question, which is stricter than the building blocks' two.
- **The do-not-contact check** matches column A against the lead's email or phone. Opt-outs from email replies are stored by email address.

## Need it installed for you?
Installs aren't available yet. On the download page, use the **"Ask about an install"** button, and we'll tell you when installs open.

## Compliance notice
See **`COMPLIANCE_NOTICE.md`** and **`compliance_building_blocks.md`**. They're general information, not legal advice; see `DISCLAIMER.md`.

## License
MIT. See `LICENSE.md`.
