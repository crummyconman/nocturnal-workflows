# Compliance Notice: Instant Lead Response (free workflow)

**Read this before you turn the workflow on.** This notice is general information, not legal advice. Laws differ by state and change often. You, the person installing and running this workflow, are responsible for how it is used. Have a lawyer or your managing broker review your consent language, messages and setup before you send to real leads.

## 1. You are the sender
When this workflow emails or texts a lead, the message is sent by you (or your brokerage), not by the author of this workflow. You are responsible for:
- having the lead's consent to contact them the way the workflow does,
- honoring every opt-out,
- following federal, state and local law, plus your brokerage's and your MLS's rules,
- the accuracy of what the AI writes in your name.

## 2. Consent (TCPA and state laws)
- **Text messages (SMS)** sent with automated technology are covered by the Telephone Consumer Protection Act (TCPA) and by state laws such as Florida's and Oklahoma's, which can be stricter. Get clear written consent on your form before you text anyone. Use the consent checkbox wording in `compliance_building_blocks.md`.
- The checkbox must be **unchecked by default** and **optional**. A lead must be able to submit the form without agreeing, and the workflow must not text a lead who didn't check it.
- Keep a record of every consent: the exact wording shown, its version, the date and time, the form page, and the phone number. The workflow logs this to your Google Sheet. Don't delete it while you might need it.
- **Leads from third parties** (Zillow, Realtor.com, Facebook Lead Ads, purchased lists) may not include consent for *your* automated messages. Check each source's terms before connecting it. Don't text purchased lists.
- **Never use this workflow for cold outreach.** It is only for replying to people who contacted you.

## 3. Quiet hours
Federal rules bar telephone solicitations before 8 a.m. and after 9 p.m. at the lead's local time, and some states stop at 8 p.m. The workflow ships set to **8 a.m. to 8 p.m.** and holds anything outside that window until morning. Set the time zone to your market. If your leads span several time zones, use each lead's own time zone before going live.

## 4. Opt-outs
- Every first text ends with "Reply STOP to opt out." Every email has an unsubscribe line and your postal address.
- Treat STOP, UNSUBSCRIBE, CANCEL, QUIT, END, and any message a reasonable person would read as "stop contacting me" as an opt-out.
- Once someone opts out, send nothing more except, at most, one plain confirmation. The workflow keeps a do-not-contact list in your Google Sheet and checks it before every send. Never delete names from that list.

## 5. Email (CAN-SPAM)
Emails must show who they're from accurately (your name or brokerage in the From line), use honest subject lines, include a valid postal address (a PO box or registered private mailbox is fine), and give a working way to opt out. The workflow honors opt-outs right away. The law allows up to 10 business days, but don't wait.

## 6. Fair Housing
The Fair Housing Act and state and local laws ban discrimination and steering based on race, color, religion, sex (including sexual orientation and gender identity), national origin, disability and familial status. Many states add more protected classes, such as age, marital status or source of income.
- The AI prompt included here tells the assistant **never** to describe or rank neighborhoods, schools, safety, crime or "who lives there," never to suggest or discourage areas, and never to ask about or use protected characteristics.
- Any question on those topics is handed to you, a human.
- A keyword filter blocks risky replies before they send. It's a backstop, not a guarantee.
- **Don't remove or weaken these guardrails.** Review the AI's messages weekly for the first month, then monthly.

## 7. AI disclosure
The assistant introduces itself as your "automated assistant" and admits it's automated whenever asked. Some states, such as California and Utah, have bot or AI disclosure laws. Don't change the prompt to make the assistant claim to be human.

## 8. Data and privacy
- Lead data passes through your form tool, Make.com, your AI provider, Google Sheets and your email or texting provider. List them in your privacy policy, and post that policy on your site before collecting leads.
- **Free AI tiers may use your data to improve their products.** Google's Gemini free tier says so on its pricing page. Use free tiers only with test data. Switch to a paid tier or a provider whose terms exclude training before you process real leads.
- Never ask for, or send by text or email, Social Security numbers, bank details or other sensitive financial data.
- Delete old transcripts on a schedule you set with your lawyer.

## 9. Texting registration
Before texting real leads in the US, register your business as the sender: A2P 10DLC for a local number, or toll-free verification for a toll-free number. The sample messages and opt-in description you submit must match what the workflow actually sends.

## 10. No warranty
This workflow is provided "as is," without warranty of any kind. Following this notice does not guarantee compliance with any law. The author is not your lawyer and accepts no liability for how you use it.

*Notice version 1.0, November 14, 2026.*
