/**
 * Instant Lead Response - unsubscribe watcher (Google Apps Script).
 * Runs inside the Gmail account that sends the lead emails.
 *
 * Every 5 minutes: finds replies to the lead email (subject below), strips
 * quoted text, and if the subject or the new text contains an opt-out word
 * (see compliance_building_blocks.md, section 3), POSTs
 *   {email, subject, reply_text, received_at}
 * to Make Scenario U ("ILR - U Unsubscribe"), which adds the address to the
 * do_not_contact tab and sends a Telegram alert to the agent.
 *
 * Setup: paste into a new Apps Script project (script.google.com) signed in
 * as the sending Gmail account, fill the two {{PLACEHOLDERS}} below, run
 * setup() once and approve the Gmail and external-request permissions.
 * No secrets live in this file. Treat the webhook URL as private anyway:
 * anyone who has it can add rows to your do_not_contact list.
 */

var WEBHOOK_URL = '{{SCENARIO_U_WEBHOOK_URL}}';           // Scenario U > webhook module > Copy address
var OWN_ADDRESS = '{{SENDER_EMAIL}}';                     // the Gmail address Scenario A sends from (lower case)
var SUBJECT = 'Your real estate inquiry';            // must match Scenario A, module 10 subject
var DONE_LABEL = 'ilr-optout-done';
var QUERY = 'subject:"' + SUBJECT + '" newer_than:2d -label:' + DONE_LABEL;
// Threads already labeled are re-checked only for NEW lead replies (e.g. "yes"
// first, then "STOP" later), using the message id stored per thread.
var RECHECK_QUERY = 'subject:"' + SUBJECT + '" newer_than:2d label:' + DONE_LABEL;
// Opt-out words, from compliance_building_blocks.md section 3. Err toward opting out.
// CONTAINS: matched anywhere in the subject or the new reply text.
var KEYWORDS = ['stop', 'unsubscribe', 'remove me', 'opt out', 'optout', 'revoke',
                "don't text", '\u2019t text', 'dont text', 'do not text',
                "don't email", 'do not email', 'do not contact', 'wrong number'];
// EXACT: short words that only count as an opt-out when they are the whole reply
// (so "send" or "this weekend" never trigger "end"). STOPALL is caught by 'stop'.
var EXACT_WORDS = ['cancel', 'end', 'quit', 'stopall', 'revoke', 'optout', 'unsubscribe', 'stop', 'opt out'];
var HANDLER = 'checkOptOuts';
var PROP_PREFIX = 'ilr_last_';                        // ilr_last_<threadId> = "<messageId>|<epoch ms>"
var MAX_THREADS = 100;

/** Run once by hand. Creates the 5-minute trigger, never a duplicate. */
function setup() {
  if (WEBHOOK_URL.indexOf('{{') !== -1 || OWN_ADDRESS.indexOf('{{') !== -1) {
    throw new Error('Fill WEBHOOK_URL and OWN_ADDRESS at the top of the file first.');
  }
  var exists = ScriptApp.getProjectTriggers().some(function (t) {
    return t.getHandlerFunction() === HANDLER;
  });
  if (!exists) {
    ScriptApp.newTrigger(HANDLER).timeBased().everyMinutes(5).create();
  }
  getOrCreateLabel_();
  Logger.log(exists ? 'Trigger already existed; nothing added.' : 'Trigger created: every 5 minutes.');
}

/** Optional: removes the trigger. */
function teardown() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === HANDLER) ScriptApp.deleteTrigger(t);
  });
}

/** Trigger handler. */
function checkOptOuts() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return;                   // a previous run is still going
  try {
    var label = getOrCreateLabel_();
    var props = PropertiesService.getScriptProperties();

    // 1) New threads (not yet labeled).
    GmailApp.search(QUERY, 0, MAX_THREADS).forEach(function (thread) {
      processThread_(thread, label, props, false);
    });

    // 2) Labeled threads: only act if a newer lead message arrived since last check.
    GmailApp.search(RECHECK_QUERY, 0, MAX_THREADS).forEach(function (thread) {
      processThread_(thread, label, props, true);
    });

    pruneProps_(props);
  } finally {
    lock.releaseLock();
  }
}

function processThread_(thread, label, props, recheck) {
  var msg = latestLeadMessage_(thread);
  // Thread holds only our own outgoing email so far: leave it unlabeled so the
  // lead's reply is still picked up later.
  if (!msg) return;

  var key = PROP_PREFIX + thread.getId();
  var seen = props.getProperty(key);
  if (recheck && seen && seen.split('|')[0] === msg.getId()) return;   // nothing new

  var subject = msg.getSubject() || '';
  var newText = stripQuoted_(msg.getPlainBody() || '');

  if (hasOptOutWord_(subject) || hasOptOutWord_(newText)) {
    var payload = {
      email: bareAddress_(msg.getFrom()),
      subject: subject,
      reply_text: newText.substring(0, 2000),
      received_at: msg.getDate().toISOString()
    };
    var res = UrlFetchApp.fetch(WEBHOOK_URL, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    if (code < 200 || code >= 300) {
      // Leave unlabeled / unrecorded so the next run retries.
      Logger.log('Webhook failed (' + code + ') for thread ' + thread.getId());
      return;
    }
  }

  // Matched or not: mark as checked.
  thread.addLabel(label);
  props.setProperty(key, msg.getId() + '|' + Date.now());
}

/** Latest message in the thread not sent by OWN_ADDRESS, or null. */
function latestLeadMessage_(thread) {
  var msgs = thread.getMessages();
  for (var i = msgs.length - 1; i >= 0; i--) {
    if (bareAddress_(msgs[i].getFrom()) !== OWN_ADDRESS) return msgs[i];
  }
  return null;
}

/** "Name <a@b.com>" -> "a@b.com" (lower case). */
function bareAddress_(from) {
  var s = String(from || '');
  var m = s.match(/<([^>]+)>/);
  var addr = m ? m[1] : s;
  var m2 = addr.match(/[^\s<>"']+@[^\s<>"']+/);
  return (m2 ? m2[0] : addr).trim().toLowerCase();
}

/** Keep only the new text: cut at "wrote:" (and its "On ..." line) or "-----Original". */
function stripQuoted_(body) {
  var text = body.replace(/\r\n/g, '\n');
  var cut = text.length;
  var w = text.indexOf('wrote:');
  if (w !== -1) {
    var onLine = text.lastIndexOf('\nOn ', w);          // start of "On <date>, <name> wrote:"
    cut = Math.min(cut, onLine !== -1 && w - onLine < 300 ? onLine : w);
  }
  var o = text.indexOf('-----Original');
  if (o !== -1) cut = Math.min(cut, o);
  text = text.substring(0, cut);
  // Drop any leftover "> quoted" lines.
  text = text.split('\n').filter(function (l) { return !/^\s*>/.test(l); }).join('\n');
  return text.trim();
}

function hasOptOutWord_(s) {
  var t = String(s || '').toLowerCase();
  if (KEYWORDS.some(function (k) { return t.indexOf(k) !== -1; })) return true;
  var whole = t.replace(/[.!,?"']/g, '').replace(/\s+/g, ' ').trim();
  return EXACT_WORDS.indexOf(whole) !== -1;
}

function getOrCreateLabel_() {
  return GmailApp.getUserLabelByName(DONE_LABEL) || GmailApp.createLabel(DONE_LABEL);
}

/** Forget threads older than 3 days (the search only looks back 2). */
function pruneProps_(props) {
  var all = props.getProperties();
  var cutoff = Date.now() - 3 * 24 * 3600 * 1000;
  Object.keys(all).forEach(function (k) {
    if (k.indexOf(PROP_PREFIX) !== 0) return;
    var ts = Number(String(all[k]).split('|')[1] || 0);
    if (ts < cutoff) props.deleteProperty(k);
  });
}
