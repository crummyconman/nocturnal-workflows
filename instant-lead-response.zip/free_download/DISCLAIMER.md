# Disclaimer

**Provided as is, with no warranty.** This workflow is free and comes with no warranty of any kind, express or implied, including that it will work, keep working, stay within any free tier, or deliver every message. Make.com, Google, Telegram and Tally change their products, prices and limits, and that can break the workflow or change what it costs. Use it at your own risk.

**Not legal advice.** Nothing in this download, including `COMPLIANCE_NOTICE.md` and `compliance_building_blocks.md`, is legal advice. Have a lawyer or your managing broker review your setup, consent wording and messages before you contact real leads.

**You are responsible for compliance.** You, the person who installs and runs the workflow, are the sender of every message it sends. You are responsible for following all laws, rules and terms that apply to you, including:
- CAN-SPAM (sender identification, a valid postal address, and honoring unsubscribes in every commercial email),
- the TCPA and state telemarketing and texting laws (prior express written consent, quiet hours, opt-outs, and carrier registration before any SMS),
- the Fair Housing Act and state and local fair housing laws,
- your state's real estate advertising and licensing rules, and your brokerage's and MLS's policies,
- the terms of every lead source you connect (for example Zillow, Realtor.com or a portal), and
- the terms and privacy rules of each service used (Make, Google Gemini, Gmail, Google Sheets, Telegram, Tally).

**Check the AI's output.** Messages are written by an AI model. The built-in prompt rules and keyword filter reduce risk but do not remove it. AI output can be wrong, off-tone or non-compliant. Review the logs, test regularly, and keep a human following up on every lead.

**Lead data.** On Google's free Gemini tier, your inputs may be used to improve Google's products. Do not send real leads' personal data through the free tier; switch to a paid tier, or a provider whose terms exclude training, first.

**No affiliation.** This project is not affiliated with, endorsed by or sponsored by Make (Celonis), Google, Telegram, Tally, Twilio or any lead source. All trademarks belong to their owners.
